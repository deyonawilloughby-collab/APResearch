usethis::use_git_config(
  user.name = "deyonawilloughby-collab",
  user.email = "deyonawilloughby@gmail.com",
)

usethis::create_github_token()
